﻿#include"function.h"
static void SetPos(int x, int y)
{
	//横为x 纵为y
	COORD point = { x,y };//光标要设置的位置x,y
	HANDLE HOutput = GetStdHandle(STD_OUTPUT_HANDLE);//使用GetStdHandle(STD_OUTPUT_HANDLE)来获取标准输出的句柄
	SetConsoleCursorPosition(HOutput, point);//设置光标位置
}

void init() 
{
	HANDLE hOutput, hOutBuf;//控制台屏幕缓冲区句柄
	//双缓冲处理显示
	hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	hOutBuf = CreateConsoleScreenBuffer(GENERIC_WRITE,
		//定义进程可以往缓冲区写数据
		FILE_SHARE_WRITE,		//定义缓冲区可共享写权限 NULL, CONSOLE_TEXTMODE_BUFFER, NULL );
		NULL,
		CONSOLE_TEXTMODE_BUFFER,
		NULL
	);
	//该段代码功能是隐藏光标，调用了win32编程接口，不需要掌握
	//:HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);//获取窗口句柄
	//:CONSOLE_CURSOR_INFO cci;//实列化一个控制台光标信息类
	//: GetConsoleCursorInfo(hOut, &cci);//获取光标信息
	//:cci.bVisible = FALSE;//隐藏光标
	//:SetConsoleCursorInfo(hOut, &cci);//设置光标信息
	//system("LIKE-EAT SKANE");//设定窗口名称
	SMALL_RECT rc;
	rc.Left = 0;
	rc.Right = 101;
	rc.Top = 0;
	rc.Bottom = 38;
	int pd1 = SetConsoleWindowInfo(hOutput, TRUE, &rc);
	SetConsoleWindowInfo(hOutput, TRUE, &rc);//设定窗口大小
	//system("c:\\windows\\system32\\mode.com con cols=100 lines=38");
	CONSOLE_CURSOR_INFO cci;
	cci.bVisible = 0;
	cci.dwSize = 1;
	SetConsoleCursorInfo(hOutput, &cci);
	SetConsoleCursorInfo(hOutBuf, &cci);
}

void initgame(Snake *head)
{
	/*需要重复初始化的数据*/

	//初始化游戏相关信息
	Inform *p_inf = &inform;
	p_inf->dirc = right;
	p_inf->is_f = FY;
	p_inf->is_inc1 = FN;
	p_inf->is_inc2 = FN;
	p_inf->is_d = F;
	p_inf->is_s = F;
	p_inf->is_r = F;
	p_inf->scene = 2;
	p_inf->Passed = 0;
	p_inf->is_speed = F;

	gamemaps(p_inf->level);
	interf(p_inf->scene);

	Snake *h = head;
	h->x = 20;
	h->y = 15;
	h->body = '@';//可更换	
	h->Snake_length = 1;
	h->prior = NULL;
	h->next = NULL;

	//初始化蛇长
	increaseSnake(head, p_inf->dirc);
	increaseSnake(head, p_inf->dirc);
}
Interfs *interf(int scene)
{
	// scene=1 Snake界面
	//scene=2 开始界面
	//scene=3 过关界面
	//scene=4 通关界面
	//scene=5 在关卡界面退出
	//scene=6 闯关失败
	Interfs *temp = &Interf;
	char game_f[256];
	sprintf(game_f, "..\\Source\\Interface\\%d.txt", scene);
	FILE *fi;
	fi = openfile(game_f, "r");
	int lines, Cols;
	fscanf(fi, "%d", &lines);
	fscanf(fi, "%d", &Cols);
	for (int i = 0; i <= lines; i++)
	{
		fgets(temp->game_interf[i], 50, fi);
		temp->game_interf[i][Cols] = '\0';
	}
	fclose(fi);
	return temp;
}
Maps* gamemaps(int level)
{
	Maps* temp = &Gmaps;
	char game_m[1000];
	sprintf(game_m, "..\\Source\\Maps\\%d.txt", level);
	FILE* fp;
	fp = openfile(game_m, "r");
	fscanf(fp, "%d", &temp->Length);
	fscanf(fp, "%d", &temp->Width);
	fscanf(fp, "%d", &temp->is_ob);
	if (temp->is_ob == T)
	{
		int i = 0;
		for (; feof(fp) == 0; ++i)
		{
			fscanf(fp, "%d", &temp->ob_x[i]);
			fscanf(fp, "%d", &temp->ob_y[i]);
		}
	}
	else
	{
		for (int i = 999; i >= 0; --i)
		{
			temp->ob_x[i] = '\0';
			temp->ob_y[i] = '\0';
		}
	}
	fclose(fp);
	return temp;
}
int event()
{
	char option;
	option = getch();
	switch (option)
	{
	case 'Q':
	case 'q'://加入双缓冲之后才//getch
		//getch();
		return 'q';
	case 'W':
	case 'w':
		//getch();
		return 'w';
	case 'N':
	case 'n':
		//getch();
		return 'n';
	case 'R':
	case 'r':
		//getch();
		return 'r';
	case 'A':
	case 'a':
		//getch();
		return 'a';
	case 'F':
	case 'f':
		//getch();
		return 'f';
	case 32:
		//getch();
		return 32;
	case 27:
		//getch();
		return 'x';
	default:
		option = getch();
	}
	switch (option)
	{
	case up:
		return up;
	case down:
		return down;
	case left:
		return left;
	case right:
		return right;
	default:
		return F;
	}
}
void checkhbit(Snake *head)
{
	int op = event();
	Inform *k_i = &inform;
	Interfs *k_f = &Interf;
	Maps *k_m = &Gmaps;
	switch (op)
	{
	case up:
		k_i->dirc = up;
		break;
	case down:
		k_i->dirc = down;
		break;
	case left:
		k_i->dirc = left;
		break;
	case right:
		k_i->dirc = right;
		break;
	case 'q':
		k_i->level = 1;
		initgame(head);
		break;
	case 32:
		k_i->is_speed = T;
		break;
	case 'w':
		saveUser();
		choose();
		initgame(head);
		break;
	case 'r':
		if (k_i->is_saver == F)
		{
			saveranking();
			k_i->is_saver = T;
		}
		k_i->is_r = T;
		k_i->is_s = F;
		break;
	case 'n':
		if (k_i->scene == 3)
		{
			++(k_i->level);
			initgame(head);
		}
		else;
		break;
	case 'a':
		initgame(head);
		break;
	case 'x':
		if (k_i->is_s == F || k_i->scene == 6||k_i->scene==3||k_i->is_r==T)
		{
			k_i->scene = 5;
			k_i->is_s = T;
			k_i->is_r = F;
			head->Snake_length = 1;//在进入下一关的时候退出
			interf(k_i->scene);
		}
		else if ((k_i->scene == 5 && k_i->is_s == T)||(k_i->scene == 4 && k_i->is_s == T))
		{		
			if (k_i->scene == 4 && k_i->is_s == T)
			{
				k_i->level = 1;
				head->Snake_length = 1;
			}
			else;
			k_i->scene = 2;
			k_i->is_s = T;
			interf(k_i->scene);			
		}
		else if (k_i->scene == 2 && k_i->is_s == T)
		{
			saveUser();
			saveranking();
			clear(head);
			exit(0);
		}
		break;
	case 'f':
		initgame(head);
		break;
	default:
		break;
	}
}
Food* createFood(Food *food, Snake *head)
{
	Food  *temp = food;
	Inform *tempI = &inform;
Again:
	srand((unsigned)time(NULL));
	temp->fo_x = 1 + rand() % 98;
	temp->fo_y = 1 + rand() % 32;
	temp->ft_x = 1 + rand() % 98;
	temp->ft_y = 1 + rand() % 32;//不能生成在墙上面
	srand((unsigned)time(NULL));
	int Foodtype = rand() % 5;//0-3:food_one; 4:food_two;
	switch (Foodtype)
	{
	case 0:
	case 1:
	case 2:
	case 3:
		temp->ftype = type1; break;
	case 4:
		temp->ftype = type2; break;
	default:
		break;
	}
	tempI->is_f = FN;
	checkfood(temp, head);
	if (tempI->is_f == FY)
		goto Again;
	return food;
}
void checkfood(Food *food, Snake *head)
{
	Food *c_f = food;
	Maps *c_m = &Gmaps;
	Inform *c_i = &inform;
	switch (c_f->ftype)
	{
	case type1:  //判断type1生成在墙上
		for (int i = 0; c_m->ob_x[i] != '\0'; i++)
		{
			if (c_f->fo_x == c_m->ob_x[i] && c_f->fo_y == c_m->ob_y)
			{
				c_i->is_f = FY;
				break;
			}
		}
		//判断type1生成在蛇身上
		Snake *judge = head;
		for (; judge != NULL; judge = judge->next)
		{
			if (c_f->fo_x == judge->x&&c_f->fo_y == judge->y)
			{
				c_i->is_f = FY;
				break;
			}
		}
		break;
	case type2:
		//判断type2生成在障碍物上
		for (int i = 0; c_m->ob_x[i] != '\0'; i++)
		{
			if (c_f->ft_x == c_m->ob_x[i] && c_f->ft_y == c_m->ob_y)
			{
				c_i->is_f = FY;
				break;
			}
		}
		//判断type2生成在蛇身上
		Snake *judge1 = head;
		for (; judge1 != NULL; judge1 = judge1->next)
		{
			if (c_f->ft_x == judge1->x&&c_f->ft_y == judge1->y)
			{
				c_i->is_f = FY;
				break;
			}
		}
		break;
	default:
		break;
	}
}
void get_dead(Snake *head)
{
	Snake *g_d = head;
	Maps *g_m = &Gmaps;
	Inform *g_i = &inform;
	//判断蛇头碰撞情况
	//判断撞墙    
	if (g_i->is_d == F && g_i->is_s == F)
	{
		if (g_d->x == 0 || g_d->x == g_m->Length - 1 || g_d->y == 0 || g_d->y == g_m->Width - 1)
		{
			g_i->is_d = T;
			goto Free;
		}
		else//判断撞到障碍物  
		{
			for (int i = 0; g_m->ob_x[i] != '\0'; i++)
			{
				if (g_d->x == g_m->ob_x[i] && g_d->y == g_m->ob_y[i])
				{
					g_i->is_d = T;
					goto Free;
				}
			}
		}
		//判断撞到蛇身

		Snake *judge1 = head, *judge2 = judge1->next;
		for (; judge2->next != NULL; judge2 = judge2->next)
		{
			if (judge1->x == judge2->x&&judge1->y == judge2->y)
			{
				g_i->is_d = T;
				goto Free;
			}
		}
		//判断撞到蛇尾
		if (judge1->x == judge2->x&&judge1->y == judge2->y)
		{
			g_i->is_d = T;
			goto Free;
		}

	}
	else;
Free://在游戏退出之前不可以释放初始化的头和蛇身
	if (g_i->is_d == T)
	{
		if ((g_i->is_inc1 == FY || g_i->is_inc2) == FY)
		{
			Snake *f_1 = head->next->next;//移动指针到生成的蛇身处
			Snake *f_2 = f_1->next;
			for (; f_2->next != NULL; f_2 = f_2->next)
			{
				free(f_1);
				f_1 = f_2;
			}
			free(f_1);
			free(f_2);
		}
		initgame(head);
		g_i->is_s = T;
		g_i->scene = 6;
	}
}
void get_food(Food *food, Snake *head)
{
	Food *g_f = food;
	Snake *g_s = head;
	Inform *g_i = &inform;
	switch (g_f->ftype)
	{
	case type1:
		if (g_s->x == g_f->fo_x&&g_s->y == g_f->fo_y)
		{
			++(g_i->is_inc1);
			createFood(g_f, g_s);
		}
		break;
	case type2:
		if (g_s->x == g_f->ft_x&&g_s->y == g_f->ft_y)
		{
			g_i->is_inc2 = FY;
			createFood(g_f, g_s);
		}
		break;
	default:
		break;
	}
	if (g_i->is_inc1 == FY || g_i->is_inc2 == FY)
	{
		increaseSnake(g_s, g_i->dirc);
		g_i->is_inc1 = FN;
		g_i->is_inc2 = FN;
	}
}
void increaseSnake(Snake *head, int dirc)
{
	Inform *i_i = &inform;
	Snake *p = head, *tail;
	++(p->Snake_length);//将蛇长存储到蛇头当中
	for (; p->next != NULL; p = p->next);
	tail = (Snake*)malloc(sizeof(Snake));
	p->next = tail;
	tail->prior = p;
	switch (dirc)
	{
	case up:
		tail->x = p->x;
		tail->y = p->y + 1;
		break;
	case down:
		tail->x = p->x;
		tail->y = p->y - 1;
		break;
	case left:
		tail->x = p->x + 1;
		tail->y = p->y;
		break;
	case right:
		tail->x = p->x - 1;
		tail->y = p->y;
		break;
	default:
		break;
	}
	tail->body = 'O';
	tail->next = NULL;
	i_i->is_inc1 = FN;
	i_i->is_inc2 = FN;
}
void move(Snake *head, int direction)
{
	drawSnake(head);
	Snake *move = head;//后一个的位置模仿前一个的位置
	for (; move->next != NULL; move = move->next);
	for (; move->prior != NULL; move = move->prior)
	{
		move->x = move->prior->x;
		move->y = move->prior->y;
	}
	switch (direction)
	{
	case up:
		move->y--;
		break;
	case down:
		move->y++;
		break;
	case left:
		move->x--;
		break;
	case right:
		move->x++;
		break;
	default:
		break;
	}

}
void render(Snake *head, Food food)
{
	//system("color 87");
	Interfs *it = &Interf;
	Maps *im = &Gmaps;
	Inform *ii = &inform;
	if (ii->is_s)
	{
		char jump[8] = "\n\n\n\n\n\n";
		puts(jump);
		char tab[7] = "\t\t\t  ";
		interf(ii->scene);
		for (int i = 0; i < 18; i++)
		{
			printf("%s", tab);
			puts(it->game_interf[i]);
		}
		if (ii->scene == 1)
		{
			getchar();
			ii->scene = 2;
		}
	}
	else if (ii->is_r)
	{
		ranking();
	}
	else
	{
		for (int i = 0; i < im->Width; i++)//i->y,j->x;
		{
			for (int j = 0; j < im->Length; j++)
			{
				if ((i == 0 || i == im->Width - 1))
					printf("=");
				else if ((j == 0&&(i!=0&&i!= im->Width-1)) || j == im->Length - 1 && (i != 0 && i != im->Width - 1))
					printf("I");
				else printf(" ");
			}
			printf("\n");
		}
		if (im->is_ob == T)
		{
			for (int i = 0; im->ob_x[i] != '\0'; i++)
			{
				SetPos(im->ob_x[i], im->ob_y[i]);
				printf("#");
			}
		}
		drawFood(food, head);
		move(head, ii->dirc);
		SetPos(30, 36);
		printf("第%d关\t退出:Esc\t操作:up dowm left rigrt",ii->level);
	}
	DoubleBuffer(hOutput, hOutBuf);

	Sleep(50);
	system("cls");
}
void drawSnake(Snake *head)
{
	Snake *drawS = head;
	for (; drawS->next != NULL; drawS = drawS->next)
	{
		SetPos(drawS->x, drawS->y);
		printf("%c", drawS->body);
	}
	SetPos(drawS->x, drawS->y);
	printf("%c", drawS->body);
}
void drawFood(Food food, Snake *head)
{
	Food *drawF = &food;
	Inform *d_i = &inform;
	if (d_i->is_f)
	{
		drawF = createFood(drawF, head);
	}
	else
	{
		switch (drawF->ftype)
		{
		case type1:
			SetPos(drawF->fo_x, drawF->fo_y);
			printf("%c", drawF->ftype_o);
			break;
		case type2:
			SetPos(drawF->ft_x, drawF->ft_y);
			printf("%c", drawF->ftype_t);
			break;
		default:
			break;
		}
	}
}
void checkPass(Snake *head)
{
	Inform *cpi = &inform;
	UserData *cpu = &curUser;
	
	if (head->Snake_length == MaxLength)
	{
		cpu->maxLevel = cpi->level;
		cpi->Passed = cpi->level;
		cpi->is_s = T;
		cpi->is_saver == F;
		saveUser();
		if (cpi->level == Maxlevel)
			cpi->scene = 4;
		else cpi->scene = 3;
	}
	else;
	
}
void choose()
{
	UserData *cs = &curUser;
	Inform *pinf = &inform;
	char filename[100];
	sprintf(filename, "..\\Data\\Userdata\\%s.txt", cs->name);
	FILE *fc = openfile(filename, "r");
	int optional;
	UserData temp;
	fread(&temp, sizeof(UserData), 1, fc);
	optional = temp.maxLevel;
	SetPos(35, 12);
	printf("这是您已经闯过的关卡,以及开放的下一关");
	SetPos(35, 13);
	if (cs->maxLevel < Maxlevel)
	{
		for (int i = 0; i <= cs->maxLevel; i++)
		{
			printf("%-4d", i + 1);
		}
		SetPos(35, 14);
		printf("请输入要选择的关卡:");
		scanf("%d", &pinf->level);
	}
}
void get_user()
{
	UserData *g_u = &curUser;
	int status;
	SetPos(35, 12);
	printf("请输入用户名:");
	scanf("%s", g_u->name);
}
void saveUser()
{
	UserData *ss = &curUser;
	Inform *sui = &inform;
	ss->maxLevel = sui->Passed;
	char filename[100];
	sprintf(filename, "..\\Data\\Userdata\\%s.txt", ss->name);
	FILE *fs = openfile(filename, "wb+");
	if (fwrite(ss, sizeof(UserData), 1, fs) != 1)
		printf("write user information wrong\n");
	fclose(fs);
	saveGame(filename);
}
void saveranking()
{
	UserData *Rsu = &curUser;
	FILE *fsr = openfile("..\\Data\\SaveGamedata\\ranking.txt", "a+");
	if (fwrite(Rsu, sizeof(UserData), 1, fsr) != 1)
		printf("save ranking wrong\n");
	fclose(fsr);
}
void ranking()
{
	Rank *Rhead = (Rank*)malloc(sizeof(Rank)), *p = NULL, *Rtail = NULL;
	Rhead->prior = NULL;
	FILE *fr = openfile("..\\Data\\SaveGamedata\\ranking.txt", "r");
	for (; !feof(fr);)
	{
		Rtail = (Rank*)malloc(sizeof(Rank));
		if (fread(&Rtail->rank, sizeof(UserData), 1, fr) != 1)
		{
			//printf("read ranking wrong\n");
			free(Rtail);
			break;
		}
		Rtail->next = NULL;
		if (p == NULL)
		{
			p = Rtail;
			Rhead->next = p;
			p->prior = Rhead;
		}
		else
		{
			p->next = Rtail;
			Rtail->prior = p;
			p = Rtail;
		}
	}
	//添加一个尾节点，使能够遍历每一个存储了数据的节点
	Rank *tail = (Rank*)malloc(sizeof(Rank));
	p->next = tail;
	tail->prior = p;
	tail->next = NULL;
	Rank *temppoint = (Rank*)malloc(sizeof(Rank));//交换的数据域
	for (Rank* temp = Rhead->next; temp->next != NULL; temp = temp->next)
	{
		for (Rank* temp1 = temp->next; temp1->next != NULL; temp1 = temp1->next)
		{
			if (temp1->rank.maxLevel > temp->rank.maxLevel)
			{
				temppoint->rank = temp1->rank;
				temp1->rank = temp->rank;
				temp->rank = temppoint->rank;
			}
		}
	}
	free(temppoint);
	//output
	Rank *output = Rhead->next;
	int i = 1;
	for (; output->next != NULL; output = output->next, i++)
	{
		SetPos(35, 12 + i);
		printf("第%d名:%s\t过关数:%d\n", i, output->rank.name, output->rank.maxLevel);
	}
	SetPos(35, i+18);
	printf("退出:Esc");
	clearR(Rhead);
}
void saveGame(char *route)
{
	FILE *fsg = openfile(route, "w");
	if (fwrite(&inform, sizeof(Inform), 1, fsg) != 1)
		printf("write game information wrong\n");
	fclose(fsg);
}
void clear(Snake *head)
{
	Snake *temp = head, *Cp;
	for (Cp = temp->next; Cp->next != NULL; Cp = Cp->next)
	{
		free(temp);
		temp = Cp;
	}
	free(temp);
	free(Cp);
}
void clearR(Rank *head)
{
	Rank *temp = head, *Cp;
	for (Cp = temp->next; Cp->next != NULL; Cp = Cp->next)
	{
		free(temp);
		temp = Cp;
	}
	free(temp);
	free(Cp);
}
FILE* openfile(char *route, char *mode)
{
	FILE *temp = fopen(route, mode);
	if (temp == NULL)
	{
		printf("wrong");
		getchar();
		exit(1);
	}
	return temp;
}


void DoubleBuffer(HANDLE hOutput, HANDLE hOutBuf)
{
	CONSOLE_CURSOR_INFO cci;
	cci.bVisible = 0;
	cci.dwSize = 1;
	SetConsoleCursorInfo(hOutput, &cci);
	SetConsoleCursorInfo(hOutBuf, &cci);
	char data[34][100];

	COORD coord = { 0,0 };
	DWORD bytes = 0;

	for (int i = 0; i <34; i++)
	{
		coord.Y = i;
		ReadConsoleOutputCharacterA(hOutput, data[i], 100, coord, &bytes);
		WriteConsoleOutputCharacterA(hOutBuf, data[i], 100, coord, &bytes);
	}
	for (int i = 0; i < 100000; i++)
	{
		for (int j = 0; j < 100000; j++)
		{
			//delay;
			
		}
	}
	SetConsoleActiveScreenBuffer(hOutBuf);
}
void cls(HANDLE hConsole)
{
	COORD coordScreen = { 0, 0 };    // home for the cursor 
	DWORD cCharsWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD dwConSize;

	// Get the number of character cells in the current buffer. 

	if (!GetConsoleScreenBufferInfo(hConsole, &csbi))
	{
		return;
	}

	dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

	// Fill the entire screen with blanks.

	if (!FillConsoleOutputCharacter(hConsole,        // Handle to console screen buffer 
		(TCHAR) ' ',     // Character to write to the buffer
		dwConSize,       // Number of cells to write 
		coordScreen,     // Coordinates of first cell 
		&cCharsWritten))// Receive number of characters written
	{
		return;
	}

	// Get the current text attribute.

	if (!GetConsoleScreenBufferInfo(hConsole, &csbi))
	{
		return;
	}

	// Set the buffer's attributes accordingly.

	if (!FillConsoleOutputAttribute(hConsole,         // Handle to console screen buffer 
		csbi.wAttributes, // Character attributes to use
		dwConSize,        // Number of cells to set attribute 
		coordScreen,      // Coordinates of first cell 
		&cCharsWritten)) // Receive number of characters written
	{
		return;
	}

	// Put the cursor at its home coordinates.

	SetConsoleCursorPosition(hConsole, coordScreen);
}
