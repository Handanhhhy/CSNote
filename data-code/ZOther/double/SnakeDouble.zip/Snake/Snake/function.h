#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<Windows.h>
#include<conio.h>
#include<wincon.h>

#define T 1
#define F 0
#define FY 3//food   ��ֹ��COORD�е� Y ��Ա����
#define FN 0//food
#define up 72
#define down 80
#define left 75
#define right 77
#define type1 1
#define type2 2
#define Maxsize 15
#define Maxlevel 2
#define MaxLength 4 //���س���

HANDLE hOutput, hOutBuf;

typedef struct _Snake
{
	int x;
	int y;
	char body;
	int Snake_length;
	struct _Snake *next;
	struct _Snake *prior;
}Snake;
typedef struct _Information
{
	int is_f;//food
	int is_inc1;//increase
	int is_inc2;
	int is_d;//dead
	int dirc;//direction
	int is_s;//scene
	int level;
	int scene;//1-6
	int is_speed;
	int is_r;
	int is_saver;
	int Passed;//��¼��������߹ؿ�
}Inform;
typedef struct
{
	int fo_x;//food_one:* -->is_inc1++;
	int fo_y;
	int ft_x;//food_two:O -->is_inc2=Y;
	int ft_y;//O:*+*+*	      
	char ftype_o;
	char ftype_t;
	int ftype;//�����ж�get_food;
}Food;
typedef struct
{
	char game_interf[50][50];
}Interfs;
typedef struct
{
	int is_ob;//�Ƿ����ϰ�����
	int Length;
	int Width;
	int ob_x[1000];
	int ob_y[1000];
}Maps;
typedef struct _UerData
{
	int NO;
	char name[Maxsize + 1];
	int maxLevel;
}UserData;
typedef struct _Rank
{
	UserData rank;
	struct _Rank *prior;
	struct _Rank *next;
}Rank;


UserData curUser;
Interfs Interf;
Maps Gmaps;
Inform inform;
void init();
int  event();
void mainLoop();
void choose();
void clear(Snake *head);
void clearR(Rank *head);
Interfs *interf(int scene);
Maps* gamemaps(int level);
void checkPass(Snake *head);
void initgame(Snake *head);
void checkhbit(Snake *head);
void move(Snake *head, int direction);
void increaseSnake(Snake *head,int dirc);
Food* createFood(Food *food, Snake *head);
void drawSnake(Snake *head);
void drawFood(Food food, Snake *head);
void get_food(Food *food, Snake *head);
void get_dead(Snake *head);
void get_user();
void saveUser();
void saveGame(char *route);
void saveranking();
void ranking();
void checkfood(Food *food, Snake *head);
void render(Snake *head, Food food);
FILE* openfile(char *route, char *mode);


void DoubleBuffer(HANDLE hOutput, HANDLE hOutBuf);
void cls(HANDLE hConsole);