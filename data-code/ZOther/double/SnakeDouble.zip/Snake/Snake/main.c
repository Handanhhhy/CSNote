#include"function.h"

int main()
{
	init();
	mainLoop();
	return 0;
}